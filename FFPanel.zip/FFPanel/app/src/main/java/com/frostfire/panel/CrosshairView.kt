package com.frostfire.panel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.view.View
import java.io.File

class CrosshairView(ctx: Context) : View(ctx) {

    companion object {
        val NAMES = listOf(
            "Plus", "Titik", "Lingkaran", "Lingkaran + titik",
            "Silang", "Huruf T", "Kurung sudut", "Plus + titik"
        )
    }

    var tint: Int = 0
        set(v) { field = v; invalidate() }

    var enemy: Boolean = false
        set(v) { if (field != v) { field = v; invalidate() } }

    private var styleId = "b0"
    private var bmp: Bitmap? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    fun useStyle(id: String) {
        styleId = id
        bmp = if (id.startsWith("c:")) {
            BitmapFactory.decodeFile(File(context.filesDir, id.substring(2)).path)
        } else null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val col = when {
            enemy -> Color.RED
            tint != 0 -> tint
            else -> Color.WHITE
        }

        val b = bmp
        if (styleId.startsWith("c:") && b != null) {
            val k = minOf(s / b.width, s / b.height)
            val dw = b.width * k
            val dh = b.height * k
            bp.colorFilter = if (enemy || tint != 0) PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN) else null
            canvas.drawBitmap(b, null, RectF(cx - dw / 2, cy - dh / 2, cx + dw / 2, cy + dh / 2), bp)
            return
        }

        val r = s / 2f - s * 0.06f
        val w = s * 0.06f
        // garis tepi gelap biar kelihatan di background terang
        p.strokeWidth = w + s * 0.04f
        p.color = Color.argb(130, 0, 0, 0)
        shape(canvas, cx, cy, r)
        p.strokeWidth = w
        p.color = col
        shape(canvas, cx, cy, r)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        c.drawLine(x1, y1, x2, y2, p)
    }

    private fun dot(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.style = Paint.Style.FILL_AND_STROKE
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
    }

    private fun plus(c: Canvas, cx: Float, cy: Float, r: Float, g: Float) {
        line(c, cx - r, cy, cx - g, cy)
        line(c, cx + g, cy, cx + r, cy)
        line(c, cx, cy - r, cx, cy - g)
        line(c, cx, cy + g, cx, cy + r)
    }

    private fun shape(c: Canvas, cx: Float, cy: Float, r: Float) {
        val g = r * 0.28f
        when (styleId) {
            "b1" -> dot(c, cx, cy, r * 0.12f)
            "b2" -> c.drawCircle(cx, cy, r * 0.8f, p)
            "b3" -> {
                c.drawCircle(cx, cy, r * 0.8f, p)
                dot(c, cx, cy, r * 0.08f)
            }
            "b4" -> {
                val d = r * 0.75f
                val e = g * 0.75f
                line(c, cx - d, cy - d, cx - e, cy - e)
                line(c, cx + e, cy + e, cx + d, cy + d)
                line(c, cx + d, cy - d, cx + e, cy - e)
                line(c, cx - e, cy + e, cx - d, cy + d)
            }
            "b5" -> {
                line(c, cx - r, cy, cx - g, cy)
                line(c, cx + g, cy, cx + r, cy)
                line(c, cx, cy + g, cx, cy + r)
            }
            "b6" -> {
                val l = r * 0.9f
                val a = r * 0.45f
                for (sx in floatArrayOf(-1f, 1f)) for (sy in floatArrayOf(-1f, 1f)) {
                    line(c, cx + sx * l, cy + sy * l, cx + sx * (l - a), cy + sy * l)
                    line(c, cx + sx * l, cy + sy * l, cx + sx * l, cy + sy * (l - a))
                }
            }
            "b7" -> {
                plus(c, cx, cy, r, g)
                dot(c, cx, cy, r * 0.08f)
            }
            else -> plus(c, cx, cy, r, g)
        }
    }
}
