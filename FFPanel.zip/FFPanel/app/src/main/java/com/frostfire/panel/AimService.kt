package com.frostfire.panel

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Menggeser kamera dengan SATU jari yang menempel dan bergerak per segmen pendek
 * (lebih mulus daripada swipe putus-putus). Jari terpisah dari sentuhan lain.
 */
class AimService : AccessibilityService() {

    companion object {
        @Volatile var instance: AimService? = null
        private var stroke: GestureDescription.StrokeDescription? = null
        private var fx = 0f
        private var fy = 0f
        private var busy = false
        private var busyAt = 0L
        private var pendingRelease = false
        private const val SEG_MS = 70L

        private fun send(s: AimService, sx: Float, sy: Float, dx: Float, dy: Float, cont: Boolean): Boolean {
            val d = stroke
            val x0 = if (d == null) sx else fx
            val y0 = if (d == null) sy else fy
            val ex = x0 + (if (abs(dx) < 1f && abs(dy) < 1f) 1f else dx)
            val ey = y0 + dy
            val path = Path()
            path.moveTo(x0, y0)
            path.lineTo(ex, ey)
            val next = if (d == null) {
                GestureDescription.StrokeDescription(path, 0, SEG_MS, cont)
            } else {
                d.continueStroke(path, 0, SEG_MS, cont)
            }
            busy = true
            busyAt = SystemClock.uptimeMillis()
            val ok = s.dispatchGesture(
                GestureDescription.Builder().addStroke(next).build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        busy = false
                        if (pendingRelease) {
                            pendingRelease = false
                            release()
                        }
                    }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        busy = false
                        stroke = null
                        pendingRelease = false
                    }
                },
                null
            )
            if (ok) {
                stroke = if (cont) next else null
                fx = ex
                fy = ey
            } else {
                busy = false
                stroke = null
            }
            return ok
        }

        /** Gerakkan jari (dx, dy) dari posisi sekarang. Mulai dari (sx, sy) kalau jari belum menempel. */
        fun move(sx: Float, sy: Float, dx: Float, dy: Float, w: Int, h: Int): Boolean {
            val s = instance ?: return false
            pendingRelease = false
            if (busy) {
                if (SystemClock.uptimeMillis() - busyAt < 500) return false
                busy = false
                stroke = null
            }
            if (stroke != null) {
                val ex = fx + dx
                val ey = fy + dy
                if (ex < w * 0.04f || ex > w * 0.96f || ey < h * 0.06f || ey > h * 0.94f) {
                    // jari hampir keluar layar: lepas, nanti mulai lagi dari titik awal
                    return send(s, sx, sy, 0f, 0f, false)
                }
            }
            return send(s, sx, sy, dx, dy, true)
        }

        /** Lepas jari. */
        fun release() {
            val s = instance ?: return
            if (stroke == null) return
            if (busy) {
                pendingRelease = true
                return
            }
            send(s, 0f, 0f, 0f, 0f, false)
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        stroke = null
        busy = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
