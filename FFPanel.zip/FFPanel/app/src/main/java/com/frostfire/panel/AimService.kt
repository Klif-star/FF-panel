package com.frostfire.panel

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Menggeser kamera dengan gesture swipe kecil. Gesture ini jari terpisah,
 * jadi tidak memutus sentuhan lain (joystick jalan, dll).
 */
class AimService : AccessibilityService() {

    companion object {
        @Volatile var instance: AimService? = null
        @Volatile private var busy = false
        @Volatile private var busyAt = 0L

        fun swipe(sx: Float, sy: Float, dx: Float, dy: Float): Boolean {
            val s = instance ?: return false
            val now = SystemClock.uptimeMillis()
            if (busy && now - busyAt < 400) return false
            val path = Path().apply {
                moveTo(sx, sy)
                lineTo(sx + dx, sy + dy)
            }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            busy = true
            busyAt = now
            val ok = s.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { busy = false }
                override fun onCancelled(gestureDescription: GestureDescription?) { busy = false }
            }, null)
            if (!ok) busy = false
            return ok
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
