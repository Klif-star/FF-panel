package com.frostfire.panel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot

class OverlayService : Service() {

    companion object {
        @Volatile var instance: OverlayService? = null
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
    }

    private val ctx: Context get() = this
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var analyzer: ScreenAnalyzer? = null
    private var xh: CrosshairView? = null
    private var xhLp: WindowManager.LayoutParams? = null
    private var bubble: TextView? = null
    private var panel: View? = null
    private var dragging = false
    private var quietUntil = 0L

    private val clearEnemy = Runnable { xh?.enemy = false }

    // 0 = warna asli
    private val palette = intArrayOf(
        0, 0xFFFFFFFF.toInt(), 0xFF00E676.toInt(), 0xFFFFEA00.toInt(),
        0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFF448AFF.toInt(), 0xFFFF9100.toInt()
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (projection == null) {
            val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
            val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
            if (data == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val pr = mpm.getMediaProjection(code, data)
            projection = pr
            addCrosshair()
            addBubble()
            analyzer = ScreenAnalyzer(this, pr) { t -> main.post { onTarget(t) } }.also { it.start() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        analyzer?.stop()
        try { projection?.stop() } catch (e: Exception) { }
        for (v in listOf<View?>(xh, bubble, panel)) {
            try { if (v != null) wm.removeView(v) } catch (e: Exception) { }
        }
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ff", "FF panel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ff")
            .setContentTitle("FF panel aktif")
            .setContentText("Tap bubble FF di game")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------- crosshair & bubble ----------

    private fun addCrosshair() {
        val v = CrosshairView(this)
        v.useStyle(Prefs.style)
        v.tint = Prefs.color
        v.visibility = if (Prefs.crosshairOn) View.VISIBLE else View.GONE
        val size = dp(Prefs.sizeDp)
        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        wm.addView(v, lp)
        xh = v
        xhLp = lp
    }

    private fun addBubble() {
        val t = TextView(this)
        t.text = "FF"
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.textSize = 16f
        t.gravity = Gravity.CENTER
        t.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xCC1E88E5.toInt())
            setStroke(dp(2), Color.WHITE)
        }
        val size = dp(46)
        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(120)

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        t.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    moved = false
                    dragging = true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    dragging = false
                    quietUntil = SystemClock.uptimeMillis() + 600
                    if (!moved) togglePanel()
                }
                MotionEvent.ACTION_CANCEL -> dragging = false
            }
            true
        }
        wm.addView(t, lp)
        bubble = t
    }

    fun onImported(name: String) {
        Prefs.style = "c:$name"
        xh?.useStyle(Prefs.style)
        if (panel != null) {
            closePanel()
            openPanel()
        }
    }

    // ---------- deteksi & aim ----------

    private fun onTarget(t: Target?) {
        val now = SystemClock.uptimeMillis()
        if (panel != null || dragging || now < quietUntil) return
        if (t == null) return
        xh?.enemy = true
        main.removeCallbacks(clearEnemy)
        main.postDelayed(clearEnemy, 400)
        if (Prefs.autoAim) aim(t)
    }

    private fun aim(t: Target) {
        val (w, h) = realScreenSize(this)
        val ty = if (Prefs.aimHead) t.headY else t.bodyY
        var dx = t.x - w / 2f
        var dy = ty - h / 2f
        if (hypot(dx, dy) < dp(10)) return
        val gain = Prefs.aimSpeed / 100f
        val maxStep = minOf(w, h) * 0.25f
        dx = (dx * gain).coerceIn(-maxStep, maxStep)
        dy = (dy * gain).coerceIn(-maxStep, maxStep)
        // swipe di area kamera (kanan layar); jari terpisah dari joystick
        AimService.swipe(w * 0.70f, h * 0.50f, dx, dy)
    }

    // ---------- panel ----------

    private fun togglePanel() {
        if (panel == null) openPanel() else closePanel()
    }

    private fun openPanel() {
        if (panel != null) return
        val h = minOf(dp(440), (resources.displayMetrics.heightPixels * 0.9f).toInt())
        val v = buildPanel()
        val lp = WindowManager.LayoutParams(
            dp(290), h, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        wm.addView(v, lp)
        panel = v
        bubble?.visibility = View.GONE
    }

    private fun closePanel() {
        val v = panel ?: return
        try { wm.removeView(v) } catch (e: Exception) { }
        panel = null
        bubble?.visibility = View.VISIBLE
        quietUntil = SystemClock.uptimeMillis() + 800
    }

    private fun label(text: String): TextView {
        val t = TextView(ctx)
        t.text = text
        t.setTextColor(0xFFB8C2D3.toInt())
        t.textSize = 12f
        t.setPadding(0, dp(8), 0, dp(3))
        return t
    }

    private fun switchRow(text: String, on: Boolean, onChange: (Switch, Boolean) -> Unit): Switch {
        val s = Switch(ctx)
        s.text = text
        s.setTextColor(Color.WHITE)
        s.isChecked = on
        s.setOnCheckedChangeListener { b, checked -> onChange(b as Switch, checked) }
        return s
    }

    private fun dropdown(items: List<String>, sel: Int, onPick: (Int) -> Unit): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val head = TextView(ctx)
        head.text = items[sel] + "  ▾"
        head.setTextColor(Color.WHITE)
        head.textSize = 14f
        head.setPadding(dp(10), dp(8), dp(10), dp(8))
        head.background = round(0xFF2A3342.toInt(), 8)
        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        list.visibility = View.GONE
        list.background = round(0xFF222A38.toInt(), 8)
        items.forEachIndexed { i, name ->
            val row = TextView(ctx)
            row.text = name
            row.setTextColor(0xFFDDE3EE.toInt())
            row.textSize = 14f
            row.setPadding(dp(10), dp(8), dp(10), dp(8))
            row.setOnClickListener {
                head.text = name + "  ▾"
                list.visibility = View.GONE
                onPick(i)
            }
            list.addView(row)
        }
        head.setOnClickListener {
            list.visibility = if (list.visibility == View.GONE) View.VISIBLE else View.GONE
        }
        box.addView(head)
        box.addView(list)
        return box
    }

    private fun seekRow(title: String, lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val tv = label("$title: $value")
        val sb = SeekBar(ctx)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                tv.text = "$title: $v"
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun colorRow(): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<TextView>()
        fun mark() {
            chips.forEachIndexed { i, c ->
                val sel = palette[i] == Prefs.color
                c.text = if (sel) "✓" else if (palette[i] == 0) "A" else ""
                c.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (palette[i] == 0) 0xFF8794AD.toInt() else palette[i])
                    setStroke(dp(1), 0x88FFFFFF.toInt())
                }
            }
        }
        for (i in palette.indices) {
            val c = TextView(ctx)
            c.gravity = Gravity.CENTER
            c.setTextColor(Color.BLACK)
            c.typeface = Typeface.DEFAULT_BOLD
            c.setOnClickListener {
                Prefs.color = palette[i]
                xh?.tint = palette[i]
                mark()
            }
            val lp = LinearLayout.LayoutParams(dp(28), dp(28))
            lp.setMargins(dp(2), 0, dp(2), 0)
            row.addView(c, lp)
            chips.add(c)
        }
        mark()
        return row
    }

    private fun buildPanel(): View {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.background = round(0xF0151B26.toInt(), 14)
        root.setPadding(dp(12), dp(10), dp(12), dp(10))

        val title = TextView(ctx)
        title.text = "FF panel"
        title.setTextColor(Color.WHITE)
        title.textSize = 17f
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(ctx)
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(switchRow("Crosshair", Prefs.crosshairOn) { _, on ->
            Prefs.crosshairOn = on
            xh?.visibility = if (on) View.VISIBLE else View.GONE
        })

        col.addView(label("Pilihan crosshair"))
        val customs = Images.customList(ctx)
        val ids = (0..7).map { "b$it" } + customs.map { "c:$it" }
        val names = CrosshairView.NAMES + customs.indices.map { "Gambar ${it + 1}" }
        val sel = ids.indexOf(Prefs.style).coerceAtLeast(0)
        col.addView(dropdown(names, sel) { i ->
            Prefs.style = ids[i]
            xh?.useStyle(ids[i])
        })

        val up = Button(ctx)
        up.text = "Upload gambar (PNG/JPG)"
        up.setOnClickListener {
            startActivity(Intent(ctx, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        col.addView(up)

        col.addView(label("Warna (A = asli)"))
        col.addView(colorRow())

        col.addView(seekRow("Ukuran", 24, 160, Prefs.sizeDp) { v ->
            Prefs.sizeDp = v
            val lp = xhLp
            val view = xh
            if (lp != null && view != null) {
                lp.width = dp(v)
                lp.height = dp(v)
                wm.updateViewLayout(view, lp)
            }
        })

        col.addView(label(" "))
        col.addView(switchRow("Auto aim", Prefs.autoAim) { sw, on ->
            if (on && AimService.instance == null) {
                toast("Aktifkan 'FF panel Auto Aim' di Aksesibilitas dulu")
                sw.isChecked = false
            } else {
                Prefs.autoAim = on
            }
        })

        col.addView(label("Target aim"))
        col.addView(dropdown(listOf("Kepala", "Badan"), if (Prefs.aimHead) 0 else 1) { i ->
            Prefs.aimHead = (i == 0)
        })

        col.addView(seekRow("Kecepatan aim", 10, 100, Prefs.aimSpeed) { v ->
            Prefs.aimSpeed = v
        })

        val foot = LinearLayout(ctx)
        foot.orientation = LinearLayout.HORIZONTAL
        val close = Button(ctx)
        close.text = "Tutup"
        close.setOnClickListener { closePanel() }
        val off = Button(ctx)
        off.text = "Matikan"
        off.setOnClickListener { stopSelf() }
        foot.addView(close, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        foot.addView(off, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(foot)
        return root
    }
}
