package com.frostfire.panel

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("ff_panel", Context.MODE_PRIVATE)
    }

    private fun s() = sp!!

    var crosshairOn: Boolean
        get() = s().getBoolean("xh_on", true)
        set(v) { s().edit().putBoolean("xh_on", v).apply() }

    // "b0".."b7" = bawaan, "c:nama.png" = gambar upload
    var style: String
        get() = s().getString("style", "b0") ?: "b0"
        set(v) { s().edit().putString("style", v).apply() }

    // 0 = warna asli
    var color: Int
        get() = s().getInt("color", 0)
        set(v) { s().edit().putInt("color", v).apply() }

    var sizeDp: Int
        get() = s().getInt("size", 64)
        set(v) { s().edit().putInt("size", v).apply() }

    var autoAim: Boolean
        get() = s().getBoolean("aim", false)
        set(v) { s().edit().putBoolean("aim", v).apply() }

    var aimHead: Boolean
        get() = s().getBoolean("aim_head", true)
        set(v) { s().edit().putBoolean("aim_head", v).apply() }

    var aimSpeed: Int
        get() = s().getInt("aim_speed", 50)
        set(v) { s().edit().putInt("aim_speed", v).apply() }
}
