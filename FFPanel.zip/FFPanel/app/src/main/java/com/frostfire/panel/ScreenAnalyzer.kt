package com.frostfire.panel

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.Display
import kotlin.math.abs

class Target(val x: Float, val headY: Float, val bodyY: Float)

fun realScreenSize(ctx: Context): Pair<Int, Int> {
    val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
    val m = DisplayMetrics()
    d.getRealMetrics(m)
    return Pair(m.widthPixels, m.heightPixels)
}

/** Tangkap layar kecil, cari objek bergerak (musuh) lewat selisih antar-frame. */
class ScreenAnalyzer(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val onFrame: (Target?) -> Unit
) {
    private val thread = HandlerThread("ff-analyzer").apply { start() }
    private val handler = Handler(thread.looper)
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0
    private var realW = 0
    private var realH = 0
    private var prev: ByteArray? = null
    @Volatile private var running = false

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { tick() } catch (e: Exception) { }
            if (running) handler.postDelayed(this, 70)
        }
    }

    fun start() {
        running = true
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stop() }
        }, handler)
        handler.post(loop)
    }

    fun stop() {
        if (!running) return
        running = false
        handler.removeCallbacksAndMessages(null)
        try { vd?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        thread.quitSafely()
    }

    private fun setup(w: Int, h: Int) {
        realW = w
        realH = h
        sw = 270
        sh = maxOf(60, (270f * h / w).toInt())
        val dpi = ctx.resources.displayMetrics.densityDpi
        reader?.close()
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        val d = vd
        if (d == null) {
            vd = projection.createVirtualDisplay(
                "ff-capture", sw, sh, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, handler
            )
        } else {
            d.resize(sw, sh, dpi)
            d.surface = r.surface
        }
        prev = null
    }

    private fun tick() {
        val (w, h) = realScreenSize(ctx)
        if (reader == null || w != realW || h != realH) setup(w, h)
        val img = reader?.acquireLatestImage() ?: return
        try {
            process(img)
        } finally {
            img.close()
        }
    }

    /** Perkiraan geseran kamera antar-frame (dx, dy) dari area di luar zona. */
    private fun estimateShift(cur: ByteArray, p: ByteArray, zx: Float, zy: Float, zr: Float): Pair<Int, Int> {
        val rng = 10
        val idx = IntArray((sw / 3 + 1) * (sh / 3 + 1))
        var cnt = 0
        var y = rng
        while (y < sh - rng) {
            var x = rng
            while (x < sw - rng) {
                val ddx = x - zx
                val ddy = y - zy
                if (ddx * ddx + ddy * ddy > (zr + 6f) * (zr + 6f)) idx[cnt++] = y * sw + x
                x += 3
            }
            y += 3
        }
        val n = cnt
        if (n < 50) return Pair(0, 0)

        fun sad(dx: Int, dy: Int): Int {
            var sum = 0
            val off = dy * sw + dx
            for (k in 0 until n) {
                val i = idx[k]
                sum += abs((cur[i].toInt() and 255) - (p[i + off].toInt() and 255))
            }
            return sum
        }

        val s0 = sad(0, 0)
        if (s0 < n * 4) return Pair(0, 0) // kamera diam
        var best = s0
        var bx = 0
        var by = 0
        for (dy in -rng..rng) {
            for (dx in -rng..rng) {
                if (dx == 0 && dy == 0) continue
                val v = sad(dx, dy)
                if (v < best) {
                    best = v
                    bx = dx
                    by = dy
                }
            }
        }
        return if (best < s0 * 0.8f) Pair(bx, by) else Pair(0, 0)
    }

    private fun process(img: Image) {
        if (img.width != sw || img.height != sh) return
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        val cur = ByteArray(sw * sh)
        for (y in 0 until sh) {
            var o = y * rs
            for (x in 0 until sw) {
                val r = buf.get(o).toInt() and 255
                val g = buf.get(o + 1).toInt() and 255
                val b = buf.get(o + 2).toInt() and 255
                cur[y * sw + x] = ((r + g * 2 + b) shr 2).toByte()
                o += ps
            }
        }
        val p = prev
        prev = cur
        if (p == null) return

        val cell = 6
        val cw = sw / cell
        val ch = sh / cell
        val dens = ctx.resources.displayMetrics.density
        val scale = sw.toFloat() / realW
        val zx = Prefs.zoneX * sw
        val zy = Prefs.zoneY * sh
        val zr = Prefs.zoneRdp * dens * scale
        val half = Prefs.sizeDp * dens * scale / 2f + cell

        // buang gerakan kamera, sisakan gerakan objek sendiri
        val (sdx, sdy) = estimateShift(cur, p, zx, zy, zr)

        val act = BooleanArray(cw * ch)
        var raw = 0
        for (cy in 0 until ch) {
            for (cx in 0 until cw) {
                var n = 0
                for (yy in 0 until cell) {
                    val y = cy * cell + yy
                    val py = y + sdy
                    if (py < 0 || py >= sh) continue
                    for (xx in 0 until cell) {
                        val x = cx * cell + xx
                        val px = x + sdx
                        if (px < 0 || px >= sw) continue
                        val d = (cur[y * sw + x].toInt() and 255) - (p[py * sw + px].toInt() and 255)
                        if (d > 35 || d < -35) n++
                    }
                }
                if (n < 11) continue
                raw++
                val mx = cx * cell + cell / 2f
                val my = cy * cell + cell / 2f
                // hanya hitung di dalam lingkaran zona
                val ddx = mx - zx
                val ddy = my - zy
                if (ddx * ddx + ddy * ddy > zr * zr) continue
                // abaikan crosshair sendiri
                if (abs(mx - sw / 2f) < half && abs(my - sh / 2f) < half) continue
                act[cy * cw + cx] = true
            }
        }

        // hampir seluruh layar berubah (pindah scene / kamera terlalu cepat) -> abaikan
        if (raw > cw * ch * 0.25f) {
            onFrame(null)
            return
        }

        val seen = BooleanArray(cw * ch)
        val stack = IntArray(cw * ch)
        var bestN = 0
        var bMinX = 0
        var bMaxX = 0
        var bMinY = 0
        var bMaxY = 0
        for (i in act.indices) {
            if (!act[i] || seen[i]) continue
            var sp = 0
            stack[sp++] = i
            seen[i] = true
            var n = 0
            var minX = cw
            var maxX = -1
            var minY = ch
            var maxY = -1
            while (sp > 0) {
                val c = stack[--sp]
                val x = c % cw
                val y = c / cw
                n++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue
                    val ni = ny * cw + nx
                    if (act[ni] && !seen[ni]) {
                        seen[ni] = true
                        stack[sp++] = ni
                    }
                }
            }
            if (n >= 2 && n > bestN) {
                bestN = n
                bMinX = minX
                bMaxX = maxX
                bMinY = minY
                bMaxY = maxY
            }
        }

        if (bestN == 0) {
            onFrame(null)
            return
        }
        val inv = realW.toFloat() / sw
        val top = bMinY * cell * inv
        val height = (bMaxY - bMinY + 1) * cell * inv
        val x = (bMinX + bMaxX + 1) / 2f * cell * inv
        onFrame(Target(x, top + height * 0.12f, top + height * 0.42f))
    }
}
