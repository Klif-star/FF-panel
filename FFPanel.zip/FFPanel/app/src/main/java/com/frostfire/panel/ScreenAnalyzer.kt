package com.frostfire.panel

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.Display
import kotlin.math.abs

class Target(val x: Float, val headY: Float, val bodyY: Float)

fun realScreenSize(ctx: Context): Pair<Int, Int> {
    val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
    val m = DisplayMetrics()
    d.getRealMetrics(m)
    return Pair(m.widthPixels, m.heightPixels)
}

/** Tangkap layar kecil, cari objek bergerak (musuh) lewat selisih antar-frame. */
class ScreenAnalyzer(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val onFrame: (Target?) -> Unit
) {
    private val thread = HandlerThread("ff-analyzer").apply { start() }
    private val handler = Handler(thread.looper)
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0
    private var realW = 0
    private var realH = 0
    private var prev: ByteArray? = null
    @Volatile private var running = false

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { tick() } catch (e: Exception) { }
            if (running) handler.postDelayed(this, 90)
        }
    }

    fun start() {
        running = true
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stop() }
        }, handler)
        handler.post(loop)
    }

    fun stop() {
        if (!running) return
        running = false
        handler.removeCallbacksAndMessages(null)
        try { vd?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        thread.quitSafely()
    }

    private fun setup(w: Int, h: Int) {
        realW = w
        realH = h
        sw = 270
        sh = maxOf(60, (270f * h / w).toInt())
        val dpi = ctx.resources.displayMetrics.densityDpi
        reader?.close()
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        val d = vd
        if (d == null) {
            vd = projection.createVirtualDisplay(
                "ff-capture", sw, sh, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, handler
            )
        } else {
            d.resize(sw, sh, dpi)
            d.surface = r.surface
        }
        prev = null
    }

    private fun tick() {
        val (w, h) = realScreenSize(ctx)
        if (reader == null || w != realW || h != realH) setup(w, h)
        val img = reader?.acquireLatestImage() ?: return
        try {
            process(img)
        } finally {
            img.close()
        }
    }

    private fun process(img: Image) {
        if (img.width != sw || img.height != sh) return
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        val cur = ByteArray(sw * sh)
        for (y in 0 until sh) {
            var o = y * rs
            for (x in 0 until sw) {
                val r = buf.get(o).toInt() and 255
                val g = buf.get(o + 1).toInt() and 255
                val b = buf.get(o + 2).toInt() and 255
                cur[y * sw + x] = ((r + g * 2 + b) shr 2).toByte()
                o += ps
            }
        }
        val p = prev
        prev = cur
        if (p == null) return

        val cell = 6
        val cw = sw / cell
        val ch = sh / cell
        val scale = sw.toFloat() / realW
        val half = Prefs.sizeDp * ctx.resources.displayMetrics.density * scale / 2f + cell

        val act = BooleanArray(cw * ch)
        var raw = 0
        for (cy in 0 until ch) {
            for (cx in 0 until cw) {
                var n = 0
                for (yy in 0 until cell) {
                    val base = (cy * cell + yy) * sw + cx * cell
                    for (xx in 0 until cell) {
                        val d = (cur[base + xx].toInt() and 255) - (p[base + xx].toInt() and 255)
                        if (d > 35 || d < -35) n++
                    }
                }
                if (n < 11) continue
                raw++
                // abaikan zona joystick kiri-bawah dan area crosshair sendiri
                if (cx < cw * 0.30f && cy > ch * 0.50f) continue
                val mx = cx * cell + cell / 2f
                val my = cy * cell + cell / 2f
                if (abs(mx - sw / 2f) < half && abs(my - sh / 2f) < half) continue
                act[cy * cw + cx] = true
            }
        }

        // kamera lagi geser (seluruh layar berubah) -> abaikan
        if (raw > cw * ch * 0.25f) {
            onFrame(null)
            return
        }

        val seen = BooleanArray(cw * ch)
        val stack = IntArray(cw * ch)
        val maxCells = (cw * ch * 0.20f).toInt()
        var bestN = 0
        var bMinX = 0
        var bMaxX = 0
        var bMinY = 0
        var bMaxY = 0
        for (i in act.indices) {
            if (!act[i] || seen[i]) continue
            var sp = 0
            stack[sp++] = i
            seen[i] = true
            var n = 0
            var minX = cw
            var maxX = -1
            var minY = ch
            var maxY = -1
            while (sp > 0) {
                val c = stack[--sp]
                val x = c % cw
                val y = c / cw
                n++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue
                    val ni = ny * cw + nx
                    if (act[ni] && !seen[ni]) {
                        seen[ni] = true
                        stack[sp++] = ni
                    }
                }
            }
            if (n >= 3 && n <= maxCells && n > bestN) {
                bestN = n
                bMinX = minX
                bMaxX = maxX
                bMinY = minY
                bMaxY = maxY
            }
        }

        if (bestN == 0) {
            onFrame(null)
            return
        }
        val inv = realW.toFloat() / sw
        val top = bMinY * cell * inv
        val height = (bMaxY - bMinY + 1) * cell * inv
        val x = (bMinX + bMaxX + 1) / 2f * cell * inv
        onFrame(Target(x, top + height * 0.12f, top + height * 0.42f))
    }
}
