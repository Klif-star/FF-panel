package com.frostfire.panel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object Images {

    fun customList(ctx: Context): List<String> =
        ctx.filesDir.listFiles()
            ?.filter { it.name.startsWith("xh_") && it.name.endsWith(".png") }
            ?.map { it.name }
            ?.sorted()
            ?: emptyList()

    /** Baca gambar PNG/JPG, hapus background otomatis, simpan. Return nama file atau null. */
    fun importCrosshair(ctx: Context, uri: Uri): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null

            val big = maxOf(src.width, src.height)
            val scaled = if (big > 256) {
                val k = 256f / big
                Bitmap.createScaledBitmap(src, maxOf(1, (src.width * k).toInt()), maxOf(1, (src.height * k).toInt()), true)
            } else src

            val cut = cropToContent(removeBackground(scaled))
            val name = "xh_${System.currentTimeMillis()}.png"
            FileOutputStream(File(ctx.filesDir, name)).use { cut.compress(Bitmap.CompressFormat.PNG, 100, it) }
            name
        } catch (e: Exception) {
            null
        }
    }

    private fun removeBackground(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        // PNG yang sudah transparan dibiarkan
        var clear = 0
        for (p in px) if ((p ushr 24) < 200) clear++
        if (clear > w * h / 50) return src

        // warna background = rata-rata 4 sudut
        val corners = intArrayOf(px[0], px[w - 1], px[(h - 1) * w], px[w * h - 1])
        var br = 0
        var bg = 0
        var bb = 0
        for (c in corners) {
            br += (c shr 16) and 255
            bg += (c shr 8) and 255
            bb += c and 255
        }
        br /= 4
        bg /= 4
        bb /= 4

        fun near(p: Int): Boolean {
            val dr = ((p shr 16) and 255) - br
            val dg = ((p shr 8) and 255) - bg
            val db = (p and 255) - bb
            return dr * dr + dg * dg + db * db < 4900
        }

        // flood fill dari tepi gambar
        val seen = BooleanArray(w * h)
        val q = IntArray(w * h)
        var head = 0
        var tail = 0
        fun push(i: Int) {
            if (!seen[i] && near(px[i])) {
                seen[i] = true
                q[tail++] = i
            }
        }
        for (x in 0 until w) { push(x); push((h - 1) * w + x) }
        for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
        while (head < tail) {
            val i = q[head++]
            val x = i % w
            val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        for (i in px.indices) if (seen[i]) px[i] = 0
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun cropToContent(b: Bitmap): Bitmap {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        var l = w
        var t = h
        var r = -1
        var btm = -1
        for (y in 0 until h) for (x in 0 until w) {
            if ((px[y * w + x] ushr 24) > 10) {
                if (x < l) l = x
                if (x > r) r = x
                if (y < t) t = y
                if (y > btm) btm = y
            }
        }
        if (r < 0) return b
        return Bitmap.createBitmap(b, l, t, r - l + 1, btm - t + 1)
    }
}
