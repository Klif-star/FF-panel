package com.frostfire.panel

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class PickActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/png", "image/jpeg"))
        }
        startActivityForResult(Intent.createChooser(i, "Pilih gambar crosshair"), 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null) {
            Prefs.init(this)
            val name = Images.importCrosshair(this, uri)
            if (name != null) {
                OverlayService.instance?.onImported(name)
                Toast.makeText(this, "Crosshair ditambahkan (background dihapus otomatis)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Gagal membaca gambar", Toast.LENGTH_SHORT).show()
            }
        }
        finish()
    }
}
