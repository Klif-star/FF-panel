package com.frostfire.panel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/** Layar penuh: gambar lingkaran zona deteksi + titik geser. Bisa digeser saat mode atur. */
class ZoneView(ctx: Context) : View(ctx) {

    var editing: Boolean = false
        set(v) { field = v; invalidate() }

    private val dens = ctx.resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xCCFFD600.toInt()
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x22FFD600
    }
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xCCFFD600.toInt()
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }
    private val loc = IntArray(2)
    private var mode = 0 // 0 tidak ada, 1 zona, 2 pegangan ukuran, 3 titik geser
    private var offX = 0f
    private var offY = 0f

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        val (w, h) = realScreenSize(context)
        val cx = Prefs.zoneX * w - loc[0]
        val cy = Prefs.zoneY * h - loc[1]
        val r = Prefs.zoneRdp * dens
        ring.strokeWidth = 2f * dens
        if (editing) c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, ring)
        if (editing) {
            c.drawCircle(cx + r, cy, 12f * dens, solid)
            txt.textSize = 12f * dens
            c.drawText("Zona deteksi", cx, cy, txt)
            val mx = Prefs.aimX * w - loc[0]
            val my = Prefs.aimY * h - loc[1]
            c.drawCircle(mx, my, 14f * dens, ring)
            c.drawCircle(mx, my, 3f * dens, solid)
            c.drawText("Titik geser", mx, my + 30f * dens, txt)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return false
        val (w, h) = realScreenSize(context)
        val zx = Prefs.zoneX * w
        val zy = Prefs.zoneY * h
        val r = Prefs.zoneRdp * dens
        val rx = e.rawX
        val ry = e.rawY
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val mx = Prefs.aimX * w
                val my = Prefs.aimY * h
                mode = when {
                    hypot(rx - mx, ry - my) < 30f * dens -> 3
                    hypot(rx - (zx + r), ry - zy) < 28f * dens -> 2
                    hypot(rx - zx, ry - zy) < r -> 1
                    else -> 0
                }
                if (mode == 1) { offX = zx - rx; offY = zy - ry }
                if (mode == 3) { offX = mx - rx; offY = my - ry }
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    1 -> {
                        Prefs.zoneX = ((rx + offX) / w).coerceIn(0f, 1f)
                        Prefs.zoneY = ((ry + offY) / h).coerceIn(0f, 1f)
                    }
                    2 -> Prefs.zoneRdp = (hypot(rx - zx, ry - zy) / dens).toInt().coerceIn(30, 250)
                    3 -> {
                        Prefs.aimX = ((rx + offX) / w).coerceIn(0.05f, 0.95f)
                        Prefs.aimY = ((ry + offY) / h).coerceIn(0.1f, 0.9f)
                    }
                    else -> { }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        invalidate()
        return true
    }
}
