package com.frostfire.panel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        val title = TextView(this)
        title.text = "FF panel"
        title.textSize = 24f
        root.addView(title)

        status = TextView(this)
        status.setPadding(0, pad / 2, 0, pad / 2)
        root.addView(status)

        fun btn(label: String, click: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { click() }
            root.addView(b)
        }

        btn("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btn("2. Aktifkan Auto Aim (Aksesibilitas)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Mulai FF panel") { start() }
        btn("Matikan FF panel") { stopService(Intent(this, OverlayService::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ac = AimService.instance != null
        status.text = "Overlay: " + (if (ov) "OK" else "belum") +
            "\nAuto Aim: " + (if (ac) "aktif" else "belum (opsional)")
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Lakukan langkah 1 dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
            i.putExtra(OverlayService.EXTRA_CODE, resultCode)
            i.putExtra(OverlayService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "Aktif. Buka game, tap bubble FF", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
