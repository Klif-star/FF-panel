# FF panel

Aplikasi Android panel melayang untuk game FF (Frost Fire).

## Fitur
- Crosshair di tengah layar: 8 bentuk bawaan, upload PNG/JPG (background dihapus otomatis), pilih warna, atur ukuran
- Crosshair berubah merah saat ada musuh (deteksi objek bergerak)
- Auto aim: geser kamera ke musuh, target Kepala/Badan, kecepatan bisa diatur

## Build APK (GitHub Actions)
1. Upload project ke repo GitHub
2. Tab Actions -> "Build APK" -> Run workflow
3. Download artifact `FF-panel-apk`

## Pasang & pakai
1. Install APK, buka app
2. Langkah 1: izin tampil di atas aplikasi lain
3. Langkah 2: aktifkan "FF panel Auto Aim" di Aksesibilitas (opsional, untuk auto aim)
   - Android 13+: kalau abu-abu, Info Aplikasi -> titik tiga -> "Izinkan setelan terbatas"
4. Langkah 3: Mulai FF panel, pilih rekam **seluruh layar**
5. Buka game, tap bubble **FF** untuk membuka panel

## Catatan
- Deteksi musuh = objek bergerak; musuh diam tidak terdeteksi
- Zona joystick kiri-bawah diabaikan
- Auto aim memakai swipe kecil di area kanan layar
